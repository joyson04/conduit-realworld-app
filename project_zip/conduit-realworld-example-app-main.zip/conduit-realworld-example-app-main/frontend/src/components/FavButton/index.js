export { default } from "./FavButton";
